import { X, Calendar, MapPin, Users, UtensilsCrossed, Star, IndianRupee, TrendingUp, AlertCircle } from 'lucide-react';
import { useEffect } from 'react';
import { STATUS_STYLES } from './EventTable';

function formatINR(amount) {
  if (!amount && amount !== 0) return '—';
  return '₹' + amount.toLocaleString('en-IN');
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

function DetailRow({ icon: Icon, label, value, valueClass = '' }) {
  return (
    <div className="flex items-start gap-4 py-4 border-b border-bookends-beige-dark last:border-0">
      <div className="w-9 h-9 bg-bookends-beige rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5">
        <Icon size={16} className="text-bookends-navy" strokeWidth={2} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">{label}</p>
        <p className={`text-bookends-navy font-semibold mt-0.5 text-sm leading-relaxed ${valueClass}`}>
          {value || '—'}
        </p>
      </div>
    </div>
  );
}

export default function EventModal({ event, onClose }) {
  useEffect(() => {
    function handleKey(e) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onClose]);

  if (!event) return null;

  const eventValue = (event.pax || 0) * (event.pricePerPax || 0);
  const collectionPct = eventValue > 0
    ? Math.round(((event.advanceReceived || 0) / eventValue) * 100)
    : 0;

  const statusStyle = STATUS_STYLES[event.status] || STATUS_STYLES['Lead'];

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="bg-white rounded-3xl shadow-2xl w-full max-w-xl animate-modalIn overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal header */}
        <div className="bg-bookends-navy-dark px-7 py-6 relative">
          <div className="h-0.5 bg-gradient-to-r from-bookends-gold to-bookends-gold-light absolute top-0 left-0 right-0" />
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-2">
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold ${statusStyle.bg} ${statusStyle.text}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${statusStyle.dot}`} />
                  {event.status}
                </span>
              </div>
              <h2 className="text-white text-xl font-bold leading-tight">{event.eventName}</h2>
              <p className="text-slate-400 text-sm mt-1 flex items-center gap-1.5">
                <MapPin size={13} />
                {event.location}
              </p>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-bookends-navy flex items-center justify-center text-slate-400 hover:text-white hover:bg-bookends-navy-light transition-colors flex-shrink-0 mt-1"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Collection progress */}
        <div className="px-7 py-4 bg-bookends-beige border-b border-bookends-beige-dark">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-medium uppercase tracking-wider">
              Collection Progress
            </span>
            <span className="text-xs font-bold text-bookends-navy">{collectionPct}%</span>
          </div>
          <div className="h-2 bg-bookends-beige-dark rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-bookends-navy to-blue-500 rounded-full transition-all duration-700"
              style={{ width: `${Math.min(collectionPct, 100)}%` }}
            />
          </div>
          <div className="flex justify-between mt-1.5">
            <span className="text-xs text-emerald-600 font-medium">{formatINR(event.advanceReceived)} received</span>
            <span className="text-xs text-red-500 font-medium">{formatINR(event.balanceDue)} pending</span>
          </div>
        </div>

        {/* Detail rows */}
        <div className="px-7">
          <DetailRow icon={Calendar} label="Event Date" value={formatDate(event.eventDate)} />
          <DetailRow icon={Users} label="Guest Count (Pax)" value={`${event.pax?.toLocaleString('en-IN')} guests`} />
          <DetailRow icon={UtensilsCrossed} label="Menu" value={event.menu} />
          {event.specialRequest && (
            <DetailRow icon={Star} label="Special Request" value={event.specialRequest} valueClass="text-amber-700" />
          )}
        </div>

        {/* Financial summary */}
        <div className="mx-7 mb-7 mt-2 bg-bookends-beige rounded-2xl p-5 grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <IndianRupee size={12} className="text-slate-400" />
              <span className="text-xs text-slate-500 uppercase tracking-wider">Per Head</span>
            </div>
            <p className="text-bookends-navy font-bold text-lg">{formatINR(event.pricePerPax)}</p>
          </div>
          <div className="text-center border-x border-bookends-beige-dark">
            <div className="flex items-center justify-center gap-1 mb-1">
              <TrendingUp size={12} className="text-slate-400" />
              <span className="text-xs text-slate-500 uppercase tracking-wider">Total Value</span>
            </div>
            <p className="text-bookends-navy font-bold text-lg">{formatINR(eventValue)}</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <AlertCircle size={12} className="text-slate-400" />
              <span className="text-xs text-slate-500 uppercase tracking-wider">Balance</span>
            </div>
            <p className={`font-bold text-lg ${(event.balanceDue || 0) > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
              {(event.balanceDue || 0) > 0 ? formatINR(event.balanceDue) : 'Cleared ✓'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
