import { Calendar, CalendarDays, IndianRupee, AlertCircle } from 'lucide-react';

function formatCurrency(amount) {
  if (amount >= 10000000) return `₹${(amount / 10000000).toFixed(2)} Cr`;
  if (amount >= 100000) return `₹${(amount / 100000).toFixed(2)} L`;
  if (amount >= 1000) return `₹${(amount / 1000).toFixed(1)}K`;
  return `₹${amount.toLocaleString('en-IN')}`;
}

function KPICard({ icon: Icon, label, value, subLabel, accent, iconBg }) {
  return (
    <div className="kpi-card flex flex-col gap-4 animate-fadeIn">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-slate-500 text-sm font-medium uppercase tracking-wider">
            {label}
          </p>
          <p
            className="text-4xl font-bold mt-2 leading-none"
            style={{ color: accent }}
          >
            {value}
          </p>
          {subLabel && (
            <p className="text-slate-400 text-xs mt-2">{subLabel}</p>
          )}
        </div>
        <div
          className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: iconBg }}
        >
          <Icon size={22} style={{ color: accent }} strokeWidth={2} />
        </div>
      </div>
    </div>
  );
}

export default function KPICards({ events }) {
  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];

  // Start of week (Monday)
  const weekStart = new Date(today);
  const day = weekStart.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  weekStart.setDate(weekStart.getDate() + diff);
  weekStart.setHours(0, 0, 0, 0);

  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);
  weekEnd.setHours(23, 59, 59, 999);

  const todayEvents = events.filter((e) => e.eventDate === todayStr);

  const thisWeekEvents = events.filter((e) => {
    const d = new Date(e.eventDate);
    return d >= weekStart && d <= weekEnd;
  });

  const totalValue = events.reduce(
    (sum, e) => sum + (e.pax || 0) * (e.pricePerPax || 0),
    0
  );

  const outstandingBalance = events
    .filter((e) => e.status !== 'Cancelled')
    .reduce((sum, e) => sum + (e.balanceDue || 0), 0);

  return (
    <div className="grid grid-cols-4 gap-5">
      <KPICard
        icon={Calendar}
        label="Today's Events"
        value={todayEvents.length}
        subLabel={
          todayEvents.length > 0
            ? todayEvents.map((e) => e.eventName).join(', ')
            : 'No events today'
        }
        accent="#1a2744"
        iconBg="#e8f0fe"
      />
      <KPICard
        icon={CalendarDays}
        label="This Week's Events"
        value={thisWeekEvents.length}
        subLabel={`Mon ${weekStart.getDate()} – Sun ${weekEnd.getDate()}`}
        accent="#2563eb"
        iconBg="#dbeafe"
      />
      <KPICard
        icon={IndianRupee}
        label="Total Event Value"
        value={formatCurrency(totalValue)}
        subLabel={`Across ${events.filter((e) => e.status !== 'Cancelled').length} active events`}
        accent="#059669"
        iconBg="#d1fae5"
      />
      <KPICard
        icon={AlertCircle}
        label="Outstanding Balance"
        value={formatCurrency(outstandingBalance)}
        subLabel="Pending collections"
        accent="#d97706"
        iconBg="#fef3c7"
      />
    </div>
  );
}
