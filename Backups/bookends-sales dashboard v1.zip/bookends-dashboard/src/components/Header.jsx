import { RefreshCw, Clock, UtensilsCrossed } from 'lucide-react';

export default function Header({ lastUpdated, onRefresh, isLoading }) {
  const formattedTime = lastUpdated
    ? lastUpdated.toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })
    : '--:--:--';

  const formattedDate = lastUpdated
    ? lastUpdated.toLocaleDateString('en-IN', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      })
    : '';

  return (
    <header className="bg-bookends-navy-dark shadow-xl">
      {/* Gold accent line */}
      <div className="h-1 bg-gradient-to-r from-bookends-gold via-bookends-gold-light to-bookends-gold" />

      <div className="px-8 py-5 flex items-center justify-between">
        {/* Logo + Title */}
        <div className="flex items-center gap-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-bookends-gold rounded-xl flex items-center justify-center shadow-lg">
              <UtensilsCrossed size={24} className="text-bookends-navy-dark" strokeWidth={2.5} />
            </div>
            <div>
              <div className="text-bookends-gold font-display text-2xl font-bold tracking-wide leading-none">
                Bookends
              </div>
              <div className="text-bookends-beige text-xs font-light tracking-[0.2em] uppercase mt-0.5">
                Catering & Events
              </div>
            </div>
          </div>

          <div className="w-px h-10 bg-bookends-navy-light mx-2" />

          <div>
            <h1 className="text-white font-semibold text-xl tracking-tight">
              Sales Event Dashboard
            </h1>
            <p className="text-slate-400 text-xs mt-0.5">{formattedDate}</p>
          </div>
        </div>

        {/* Right: timestamp + refresh */}
        <div className="flex items-center gap-6">
          <div className="text-right">
            <div className="flex items-center gap-2 justify-end">
              <Clock size={13} className="text-bookends-gold" />
              <span className="text-slate-400 text-xs uppercase tracking-widest">
                Last updated
              </span>
            </div>
            <div className="text-white font-mono text-lg font-semibold mt-0.5">
              {formattedTime}
            </div>
          </div>

          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="flex items-center gap-2.5 bg-bookends-navy-light hover:bg-bookends-navy px-5 py-3 rounded-xl text-white text-sm font-semibold transition-all duration-200 disabled:opacity-50 border border-bookends-navy hover:border-bookends-gold group"
          >
            <RefreshCw
              size={16}
              className={`transition-transform ${isLoading ? 'animate-spin' : 'group-hover:rotate-180 duration-500'}`}
            />
            {isLoading ? 'Refreshing…' : 'Refresh'}
          </button>
        </div>
      </div>
    </header>
  );
}
