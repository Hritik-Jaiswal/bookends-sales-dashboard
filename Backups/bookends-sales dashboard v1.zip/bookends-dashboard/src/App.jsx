import { useState, useEffect, useCallback, useMemo } from 'react';
import Header from './components/Header';
import KPICards from './components/KPICards';
import Filters from './components/Filters';
import EventTable from './components/EventTable';
import EventModal from './components/EventModal';
import { fetchEvents } from './services/api';

export default function App() {
  const [events, setEvents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEvent, setSelectedEvent] = useState(null);

  const loadEvents = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await fetchEvents();
      setEvents(data);
      setLastUpdated(new Date());
    } catch (err) {
      setError(err.message || 'Failed to load events');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadEvents();
    // Auto-refresh every 5 minutes
    const interval = setInterval(loadEvents, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [loadEvents]);

  // ─── Filtering logic ────────────────────────────────────────────────────────
  const filteredEvents = useMemo(() => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    // Week boundaries (Mon–Sun)
    const weekStart = new Date(today);
    const day = weekStart.getDay();
    weekStart.setDate(weekStart.getDate() + (day === 0 ? -6 : 1 - day));
    weekStart.setHours(0, 0, 0, 0);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);
    weekEnd.setHours(23, 59, 59, 999);

    // Month boundaries
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59);

    return events.filter((e) => {
      // Date filter
      let passesDate = true;
      if (activeFilter === 'today') {
        passesDate = e.eventDate === todayStr;
      } else if (activeFilter === 'week') {
        const d = new Date(e.eventDate);
        passesDate = d >= weekStart && d <= weekEnd;
      } else if (activeFilter === 'month') {
        const d = new Date(e.eventDate);
        passesDate = d >= monthStart && d <= monthEnd;
      }

      // Search filter
      let passesSearch = true;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        passesSearch =
          e.eventName?.toLowerCase().includes(q) ||
          e.location?.toLowerCase().includes(q) ||
          e.status?.toLowerCase().includes(q) ||
          e.menu?.toLowerCase().includes(q) ||
          e.eventDate?.includes(q);
      }

      return passesDate && passesSearch;
    });
  }, [events, activeFilter, searchQuery]);

  return (
    <div className="min-h-screen bg-bookends-beige flex flex-col">
      <Header
        lastUpdated={lastUpdated}
        onRefresh={loadEvents}
        isLoading={isLoading}
      />

      <main className="flex-1 p-6 space-y-6 max-w-[1800px] mx-auto w-full">
        {/* Error banner */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-2xl px-6 py-4 flex items-center gap-3">
            <span className="font-semibold">Error:</span> {error}
            <button
              onClick={loadEvents}
              className="ml-auto text-red-600 underline text-sm hover:no-underline"
            >
              Retry
            </button>
          </div>
        )}

        {/* KPI Section */}
        <KPICards events={events} />

        {/* Filters */}
        <div className="bg-white rounded-2xl px-6 py-4 border border-bookends-beige-dark shadow-sm">
          <Filters
            activeFilter={activeFilter}
            onFilterChange={setActiveFilter}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            totalShown={filteredEvents.length}
            totalAll={events.length}
          />
        </div>

        {/* Main Table */}
        <EventTable
          events={filteredEvents}
          onRowClick={setSelectedEvent}
          isLoading={isLoading}
        />
      </main>

      {/* Modal */}
      {selectedEvent && (
        <EventModal event={selectedEvent} onClose={() => setSelectedEvent(null)} />
      )}
    </div>
  );
}
